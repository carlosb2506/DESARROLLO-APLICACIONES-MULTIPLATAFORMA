package bicicleta;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class biciclista {

	public static void main(String[] args) {
		try {
			Connection con = DriverManager.getConnection("jdbc:sqlite:C:\\PruebasJava\\Ciclista.db");
			
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM Ciclista");
			
			while (rs.next()) {
				System.out.println(rs.getString("NOMBRE") + " " + rs.getInt("EDAD") + " " + rs.getInt("AGUANTA") + " " + rs.getString("COLORC"));
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
