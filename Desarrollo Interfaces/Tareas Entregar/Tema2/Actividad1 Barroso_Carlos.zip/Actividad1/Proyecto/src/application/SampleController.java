package application;

import javax.swing.JOptionPane;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class SampleController {
	
	public TextField txtNum1;
	public TextField txtNum2;
	public TextField txtResultado;
	public RadioButton rbSuma;
	public RadioButton rbResta;
	public RadioButton rbMultiplica;
	public RadioButton rbDivide;
	
	public void btnOperar() {
		
		try {
			
			int num1, num2, resultado = 0;
			
			num1 = Integer.parseInt(txtNum1.getText());
			num2 = Integer.parseInt(txtNum2.getText());
			
			if (rbSuma.isSelected()) {
				try {
					num1 = Integer.parseInt(txtNum1.getText());
					num2 = Integer.parseInt(txtNum2.getText());
					
					resultado = num1 + num2;
					
					txtResultado.setText("" + resultado);
				} catch (Exception e) {
					Alert alerta = new Alert(AlertType.ERROR);
					alerta.setHeaderText("Error en la suma");
					alerta.setTitle("ERROR");
					alerta.setContentText(e.toString());
					alerta.setContentText("Formato incorrecto");
				}
				
			} else if (rbDivide.isSelected()) {
				
				try {
					num1 = Integer.parseInt(txtNum1.getText());
					num2 = Integer.parseInt(txtNum2.getText());
					
					if (num1 == 0 || num2 == 0) {
						JOptionPane.showMessageDialog(null, "No es posible realizar una division entre 0");
					}
					
					resultado = num1 / num2;
					
					txtResultado.setText("" + resultado);
				} catch (Exception e) {
					Alert alerta = new Alert(AlertType.ERROR);
					alerta.setHeaderText("Error en la division");
					alerta.setTitle("ERROR");
					alerta.setContentText(e.toString());
					alerta.setContentText("Formato incorrecto");
				}
				
			} else if (rbResta.isSelected()) {
				
				try {
					num1 = Integer.parseInt(txtNum1.getText());
					num2 = Integer.parseInt(txtNum2.getText());
					
					resultado = num1 - num2;
					
					txtResultado.setText("" + resultado);
				} catch (Exception e) {
					Alert alerta = new Alert(AlertType.ERROR);
					alerta.setHeaderText("Error en la resta");
					alerta.setTitle("ERROR");
					alerta.setContentText(e.toString());
					alerta.setContentText("Formato incorrecto");
				}
				
			} else if (rbMultiplica.isSelected()) {
				
				try {
					num1 = Integer.parseInt(txtNum1.getText());
					num2 = Integer.parseInt(txtNum2.getText());
					
					resultado = num1 * num2;
					
					txtResultado.setText("" + resultado);
				} catch (Exception e) {
					Alert alerta = new Alert(AlertType.ERROR);
					alerta.setHeaderText("Error en la multiplicacion");
					alerta.setTitle("ERROR");
					alerta.setContentText(e.toString());
					alerta.setContentText("Formato incorrecto");
				}
			}
			
		} catch (Exception e) {
			System.out.println("Pasa por la excepcion");
			Alert alerta = new Alert(AlertType.ERROR);
			alerta.setHeaderText("Error en la suma");
			alerta.setTitle("ERROR");
			alerta.setContentText(e.toString());
			alerta.setContentText("Formato incorrecto");
		}
	}
}
